GameCube PSO Loader V2.0 by Costis!
-----------------------------------

Updates from PSOload V1.1
-------------------------

- Full 24MB of RAM uploading support for DOL and binary files.
- Highly improved upload rate: ~800-1024KBytes per second.
  (Around 20 times faster than all of the previous loaders!)
- Added support for new Japanese PSO versions Episode 3 and
  Episodes I and II Plus. All versions of PSO should now be
  supported!
- Improved automatic detection to work with every version of PSO,
  manual version specification should never have to be used again.
- DOL reloader support! (Reload new DOL or binary files without
  restarting your GameCube and PSO.)
- Completely fixed DOL loader! There should not be any more problems
  with the DOL loader at all, meaning that all working DOL files
  should also work with this new version of PSOload as well.
- User data saving support (-s option). If you are creating a new
  user account in PSO, run "PSOload -s" the first time and connect
  to it in order to save your user name, pass-word, etc. so that you
  do not have to reenter them every single time you want to upload
  code.

DOL and binary files can now use any range of RAM from 0x80003100
to 0x81800000 when initially loaded and can be up to ~24MB in size.
If you try loading files which are relatively large (like 2MB or so),
you should definitely notice a significant speed difference from
the other versions. A 2MB file should take approximately 2 to 3
seconds to upload and execute depending on your configurations.

You do NOT need an external DNS server with PSOload anymore. It
has a built-in one. This has been the case since PSOload V1.1, but many
did not notice the update and were still trying to use DNS servers
with it.

I have also included the fixed demo and an updated crt0.s file
from the previous version of PSOload. The old demo did not work
properly due to some debug code that I accidentally left inside
it before releasing. It is now called "testdemo4.dol". I have
added BSS clearing support to the crt0.s file, so global variables
should now be correctly cleared upon program initialization.

Uploading DOL\binary files
--------------------------

Most users can simply use PSOload without any parameters
other than the DOL file, like so:

PSOload.exe testdemo4.dol

Therefore, you can simply drag and drop a DOL or binary file over
the PSOload V2.0 executable. PSOload V2.0 uses a UDP port for
uploading the code (default: 9002) to the GameCube. If port 9002
is not free on your PC, you may have to specify another one, such
as 9003, etc.:

PSOload.exe -u9003 testdemo4.dol

Reloading a new DOL\binary file
-------------------------------

The DOL reloader feature can be used if the currently running DOL
file has been booted with PSOload V2.0 and supports branching to
to the DOL reloader code. Information for adding support for this
to your home-brew GameCube programs is shown below:

In order to reload a new DOL file,
execute PSOload first with the "-r" option, like so:

PSOload -r testdemo4.dol

After PSOload is waiting to send a new DOL file, the currently
running DOL file simply has to branch to 0x80001800 for the
new DOL to be loaded. For this to work, the program must NOT clear
the data at that reserved exception vector (0x80001800 to 0x80003000).
This area is normally not touched, so there should not be any
conflicts with this. The DOL reloader at 0x80001800 just requires
a valid stack pointer (r1) to be set and nothing else. It disables
sound output, interrupts, etc. by itself. In order to call it,
either C function pointer code or inline assembly code must be used.
Here is an example implementation using inline PowerPC assembly:

...
if (buttons_pressed & PAD_START)
{
   asm ("lis 3, 0x8000");
   asm ("ori 3, 3, 0x1800");
   asm ("mtlr 3");
   asm ("blrl");
}
...

As mentioned before, PSOload must be running with the "-r" option
before the DOL reloader is invoked on the GC side for it to work.
I will probably release some code built-into GCLIB for detecting
when "PSOload -r" is executed on the PC and automatically branching  
to the DOL reloader, but this method by itself should hopefully
save much more development time. Also, the DOL reloader uses the same
IP\hardware address and port configurations as the original DOL loader
was configured with, so if you have booted the first DOL file with
a different UDP port parameter (-u9003, for example), then you must
also specify that in the parameters of PSOload when reloading a
new DOL file:

PSOload.exe -u9003 -r testdemo4.dol

If PSOload V2.0 tells you that it could not locate the PC IP address,
when using the "-r" option, then you must specify it manually. Only
the first three values of the PC LAN IP address matter as the fourth
value of the IP address is fixed for the GC (*.*.*.254). For example,
if you specify:

PSOload.exe -r192.168.0.0 testdemo4.dol

It will use 192.168.0.254 as the GC IP as that is how the DOL
reloader has been originally configured by PSOload the first time
that it was used.

Note: ONLY specify an IP address when PSOload CANNOT automatically
detect the PC's LAN IP address or if for some reason it detects
the first three values of it incorrectly. Other-wise, you should
simply use the "-r" feature without any IP address following it.

Saving User Data (-s option)
----------------------------

I have implemented a feature in PSOload V2.0 that allows PSO account
user data to be saved. This is especially useful for new accounts.
If you create a new PSO account and use it just for PSO code uploading,
PSO will request your user name\pass-word information every single time.
In order to "save" this data, a confirmation must be sent from the server.
This is the purpose of the "-s" option in PSOload V2.0. Upon the creation
of a new account to be used for code uploading, execute "PSOload -s"
(without any DOL or binary file) on the PC and have PSO connect to it.
PSOload V2.0 will confirm the user data submitted (this takes around
3 seconds on the PSO side) and will disconnect. Now you should not have
to reenter your user data every time you wish to connect to your PC for
code uploading and can freely use PSOload V2.0 normally. You should
only have to use "PSOload -s" once for every new account that you create,
although using it more than once on an account with user data that is
already "saved" will not cause any harm. Finally, if you are using the
same account for online game-play on the official Sega servers, you
should not have to use this feature at all. 


As always, please e-mail any suggestions, bug reports, and constructive
criticism to costis@NOSPAMgbaemu.com. (Remove the NOSPAM part of the
address before e-mailing.) PSOload bug reports and error e-mails are
very welcome as they help me improve the program for future versions.

Specific Notes for PSO Episode 3 and PSO Episodes I and II Plus
---------------------------------------------------------------

These are the newest Japanese PSO versions currently released and
have not yet been released in the U.S. or Europe. Sega\Nintendo has
updated their network code so that it can only connect to WAN IP's,
rather than LAN IP's as well. That means that in order to use them
with PSOload V2.0, you must either use an Action Replay code to
patch the code in PSO which checks the server IP, or you must
use a router to connect to the PC's WAN IP instead of LAN IP.
To accomplish the second option, you must set up your own DNS server
to point to the WAN IP of your PC rather than the official
Sega server IP or your PC's LAN IP. Instructions for setting up
a DNS server are in the old readme file which is attached to the end
of this one. If using a cross-over cable rather than a router, it
should be possible to change your PC's LAN IP so that it looks
like a WAN IP and tricks PSO into connecting to it anyway. In any
case, using these two new versions for code uploading may possibly
be a bit tedious to set up, but should work just as well as all of
the other versions when configured properly.

Old readme (for previous PSOload versions)
------------------------------------------

NOTE: DO NOT READ THIS PART (EXCEPT POSSIBLY THE INTRODUCTION, IF
      YOU HAVE NOT READ IT BEFORE) IF YOU ARE USING THE LATEST
      VERSION OF PSOLOAD!

Updates
-------

PSOload Version 1.1 has many new features:

- Automatic PSO version detection
- Built-in DNS service (thanks to some code from Titanik)
- Fixed DOL and binary loaders.
  (All working demos should be bootable with PSOload now!)
- Increased maximum DOL and binary file upload size to 16MB!
  (With a maximum section size of 16MB as well.)
- Fixed sound beeping problems.

It has taken a very long time for the release of this version, but it is
finally here! The DOL and binary loaders had several bugs in the previous
version, which caused problems with many of the currently released demos.
These have all been fixed, and I have also attached a new (and much better)
demo and the crt0.s from my GCLIB libraries. The full libraries with source
code will be released within the next few weeks as well.

Introduction
------------

The GameCube is one of the only modern (and old) consoles without any real
homebrew development on it. This is mostly because Nintendo did a very good
job in protecting the GameCube from running custom, non-official program 
code. In fact, they did such a great job as without Sega's PSO, there would 
still not be a way to run homebrew code on the GameCube to this day. Recently, 
Sega ported PSO (along with many other previous games) to the Xbox and the 
GameCube. A friend knew that there was a way to exploit PSO to upload and 
execute homebrew code and with a lot of his help, I was able to reverse 
engineer a small part of the protocol and discover how to actually upload 
the code. So, I wrote a little program to upload GC programs to PSO and 
execute them. Currently, only binary and DOL formats are supported. I would 
like to stress that piracy is very bad, especially for the GameCube, and I 
will not condone it. This program is for homebrew development, NOT for piracy 
and other illegal activities. If you want to pirate a GameCube game, then 
first of all it's not possible (and hopefully never will be) and second of 
all this is not the right program for it.

Note: PAL PSO support should be fixed in this version!


Instructions
------------

To use this GameCube PSO code loader, you must trick PSO into believing that
it is the real Sega server. This is done by faking the IP address returned by
the DNS server that PSO has been set up to use. There are many programs that
will allow you to set up a local DNS service or a DNS cache to trick PSO into
connecting to the code loader instead of the actual multi-player online servers.
A friend, DesktopMa, has written a nice little tutorial that describes how to
set up a DNS service program to work with PSO. This document can be currently
found at: http://www.auby.no/psodns.txt. Once you have set up the DNS server
program, PSO will connect to the PSO code loader instead and you should not
have to touch it again afterwards. An account with the official Sega servers
is NOT required to use this program. Also, please note that by tricking PSO
and by using this program to send homebrew program code to your GameCube, you
are breaching the official license agreement that you must agree to before
starting the game and that it is completely your responsibility.
 
Well, the instructions in the actual program itself should be pretty much
self-explanatory. The program supports all of the PSO regions, although the
default one is U.S. version 1.1. If you have the Japanese version of PSO,
you should know which version you own: V1.0 (J as a parameter) or V1.1 (J2
as a parameter). As for the U.S. version, if you bought it pretty recently
then you probably have the latest version, V1.1 (U2 as a parameter).
Otherwise, you'll have the first version, V1.0 (U as a parameter in the
program). There is only one European PAL version of PSO (E as a parameter),
although there are two settings, 50Hz and 60Hz. 60Hz mode uses port 9200,
while 50Hz mode uses port 9201. The default port used when the European
version is specified as a parameter is 9200, so if you want to use 50Hz
mode, you must specify a custom port (9201).

I have attached a little demo, which I wrote a few a days ago, to the
code loader, so that it can easily be tested. This demo is completely
SDK-less, free, and can be  compiled with any PPC 750 compatible GCC
build (such as Torlus' build at http://heliscar.com/greg/. (I will be
releasing the full source code once I clean it up a bit.) The demo is
very simplistic due to the lack of time. It just displays a static
back-ground picture drawn by MrMr[iCE] with text saying "It works!!!".
Hopefully, I will find the time to continue working on it and add some
neat effects. :) As it is a DOL file, an entry point does not have to be
specified. Here are examples on how to load and execute the demo on all
of the PSO versions:

PSOload -vU testdemo.dol (U.S. V1.0)
PSOload -vU2 testdemo.dol (U.S. V1.1)
PSOload -vJ testdemo.dol (JPN V1.0)
PSOload -vJ2 testdemo.dol (JPN V1.1)
PSOload -vE testdemo.dol (PAL 60Hz)
PSOload -vE -p9201 testdemo.dol (PAL 50Hz)

Note: If you are planning on initializing and using the Graphics 
Processing unit of the GameCube, you must first abort the current frame 
before actually initializing\using it. This is due to the fact that PSO was 
using the Graphics Processing previously and it may still be processing a 
graphics frame when your program begins to execute.

Credits and Greetings
---------------------

These people have helped with various aspects of the program,
including giving me advice for the program, finding specific
offsets for me, and beta testing it on different versions of PSO:

crusader of kalisto (thanks a lot for all your help!)
Sappharad
Ben[SF]
DesktopMa
SSilver2k2
Parasyte
Titanik[CZN]
dovoto
woo
Guyfawkes
FreeGameboy (thanks for the writing the MOD music used in my demo!)
Torlus (thanks for the great GCC build!)

Greetings to all of the future homebrew GameCube developers! ;)

This program is officially hosted and maintained at http://www.gcdev.com.

Please e-mail any suggestions, bug reports, and constructive criticism to 
costis@NOSPAMgbaemu.com. (Remove the NOSPAM part of the address before 
e-mailing.)

WARNING: THIS PROGRAM IS NOT AFFILIATED WITH NEITHER SEGA NOR NINTENDO. 
BY USING THIS PROGRAM, ANY ILLEGAL ACTIVITY OR BREACHING OF LICENSING 
AGREEMENTS IS YOUR RESPONSIBILITY, NOT THE AUTHOR'S.