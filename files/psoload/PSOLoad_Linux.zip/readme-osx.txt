Original GameCube PSO Loader V2.0 by Costis!
--------------------------------------------

Mac OSX & Linux ports by Jouni 'Mr.Spiv/TRSi' Korhonen
------------------------------------------------------

	PSOLoad v2.0+ OSX version is based on Costis' PSOLoad v2.0 and 
	MiniDNS by xor37h/Hitmen.
	Read the Windows' docs for the PSOLoad features as they are almost
	identical.

	This PSOLoad program has been tested on my G4 PowerMac running OSX
	10.3.3, Jap/US (modded) Gamecube, and US version of the PSO.
	I have tested three dol-files:
		- testdemo4 by Costis
		- gx_demo by tmbinc
		- zImage from www.gc-linux.org
	If you find bugs.. contact Costis (or me).

	Note that OSX port does not assume or hardcode IP addresses. So you
	can not rely that PSOLoad will use x.y.z.240 for Gamecude.


How to use (OSX):
-----------------

	1) First check that the Rendezvous service is not running. You can
	   disable it manually from the terminal by issuing the following
	   command:
	   /System/Library/StartupItems/mDNSResponder/mDNSResponder stop
	   You can/should also disable rendezvous from
	   /Applications/utilities/Directory Access.app

	   Note! The above appliest only to 10.2.x OSX. On 10.3.x OSX you
	   don't need to stop Rendezvous.

	2) If you are using the PSOLoad internal DNS server make sure that you
	   are either root or the PSOLoad binary has suidroot privileges.
	   This is required because the DNS server uses port 53 and using
	   that port requires some privileges...
	   
	3) If you are using the MiniDNS server the text in 2) applies also.
	
	4) Configure the PSO DNS server to point either to a machine the
	   MiniDNS is running or to the machine you are running PSOLoad.
	   You can always configure your DHCP to point to your machine
	   running the PSOLoad or the MiniDNS and let the PSO to pick up DNS
	   server from the DHCP.
	    
	5) Run your .dol files.. Basic steps are:
	
		- Run psoload with appropriate parameters
		- Start PSO online gaming
		_ Wait...


Examples:
---------

	Using build in DNS server & default host address:
	
		./psoload dolfile.dol
		
	Using build in DNS server & forced address:
	
		./psoload -i 205.166.76.26 dolfile.dol
		
	Using external DNS (like MiniDNS):
	
		./psoload -d dolfile.dol
		
	Launching MiniDNS and returning 10.11.12.13 on every query:
	
		./minidns 0.0.0.0 209.247.228.201

	Using the reloading feature (the IP address is GC's IP):
    
		./psoload -R 10.11.12.13 dolfile.dol

	Forcing Ethernet address (the IP address is PC's IP):
    
		./psoload -i 205.166.76.26 -E 00:11:22:33:44:55 dolfile.dol



Real life examples from my setup:
---------------------------------

	My network is totally inside a private address space and my machine
	has no DNS name what so ever. The IP address of my Mac is
	10.141.153.219 and the IP address of my GC is 10.141.153.218. The
	netmask is 255.255.255.248. GC's DNS settings point to 10.141.153.219
	i.e. to my Mac.
	
	So to run e.g. testdemo4.dol I do the following:
	
	1) psoload2 -i 10.141.153.219 testdemo.dol
	2) run PSO and enter the online game mode
	3) wait..

	I use -i option to tell the build-in DNS server that "PSO server" is
	my Mac. This is because the PSOLoad2 would anyway fail to get the IP
	address of my Mac  (and I'm too bored to configure stuff properly).

	And how to use the fast reload option (for programs that support it -
	like testdemo4.dol):
	
	1) assuming testdemo4.dol is already running..
	2) psoload2 -R 10.141.153.218 gx_demo.dol
	3) press "start" on GC
	4) wait..
	
	Last time when I ran testdemo4.dol the PSOLoad2 told the GC the
	ethernet address of my Mac. Thus no need to use -E option for that
	purpose. I use -R option to tell the PSOLoad2 the address of my GC
	because the "automatic" address generation code is kind of a dump
	and would force the GC IP address to be 10.141.153.240, which in my
	case isn't be possible due my network mask.


Notes:
------

	If the PSOLoad fails to upload your .DOLs and the error complains 
	about invalid offsets, then check if there is a lot of other traffic
	on the same LAN where your GC is located. Some times heavy background
	traffic causes weird phenomenons.. poltergeists.. and others.


Contact & stuff:
----------------

	Jouni 'Mr.Spiv/TRSi' Korhonen
	
	email: mouho@iki.fi
	web:   www.deadcoderssociety.tk

	Don't mail me how to set up your networking environment!


Greetings:
----------

	Costis, Groepaz, Sjaak, Peitchi, etc etc
	mithris, _mp_, Darkfader, Flav0r, mr.trans,
	rlyeh, Kojote, Hando, Guyfawkes, Yado, TRSi!!!,
	black--, giffel, [sod]thor, tmb^scx, robbrown,
	#gp32dev@efnet, #amigaexotic@ircnet, #pdroms@efnet,
	#gcdev@efnet, ...
